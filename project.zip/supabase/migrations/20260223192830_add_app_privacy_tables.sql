BEGIN;

CREATE TABLE IF NOT EXISTS public.app_analyses (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    app_name TEXT NOT NULL,
    app_id TEXT,
    icon_url TEXT,
    permissions JSONB NOT NULL,
    analysis_result JSONB NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.app_comparisons (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    app1_name TEXT NOT NULL,
    app2_name TEXT NOT NULL,
    comparison_result JSONB NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE public.app_analyses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.app_comparisons ENABLE ROW LEVEL SECURITY;

-- Create policies (Allow anyone to read and insert for this demo)
CREATE POLICY "Allow public read access on app_analyses" ON public.app_analyses FOR SELECT USING (true);
CREATE POLICY "Allow public insert access on app_analyses" ON public.app_analyses FOR INSERT WITH CHECK (true);

CREATE POLICY "Allow public read access on app_comparisons" ON public.app_comparisons FOR SELECT USING (true);
CREATE POLICY "Allow public insert access on app_comparisons" ON public.app_comparisons FOR INSERT WITH CHECK (true);

COMMIT;
